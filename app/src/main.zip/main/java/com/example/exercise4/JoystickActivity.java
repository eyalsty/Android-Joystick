package com.example.exercise4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class JoystickActivity extends AppCompatActivity  implements JoystickView.JoystickListener  {

    TcpClient myClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        JoystickView joystickView = new JoystickView(this);
        setContentView(joystickView);

        Intent intent=getIntent();
        String ip = intent.getStringExtra("ip");
        int port = intent.getIntExtra("port_int",0);
        myClient = new TcpClient(ip,port);
    }

    @Override
    public void onJoystickMoved(float xPercent, float yPercent, int id) {
        String elevator_path = "set controls/flight/elevator" + yPercent + "\r\n";
        String aileron_path = "set controls/flight/aileron" + xPercent + "\r\n";

        myClient.sendMessage(elevator_path);
        myClient.sendMessage(aileron_path);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        myClient.stopClient();
    }
}
